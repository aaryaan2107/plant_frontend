import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { PlantserviceService } from 'src/service/plantservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {

  username: string = '';
  password: string = '';
  errorMessage: string = '';

      constructor(private Plantservice:PlantserviceService ,private router:Router){}
  
      login() {
        this.Plantservice.login(this.username, this.password).subscribe(
          (response) => {
            console.log('Logged in successfully');
            this.router.navigate(['/index']);
          },
          (error) => {
            this.errorMessage = 'Enter Valid username or password';
            console.error('Login failed', error);
            this.router.navigate(['/login']);

          }
        );
      }
    }
    
    
    